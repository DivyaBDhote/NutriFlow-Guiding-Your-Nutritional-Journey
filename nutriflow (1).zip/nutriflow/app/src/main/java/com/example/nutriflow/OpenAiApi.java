package com.example.nutriflow;

import android.os.StrictMode;

import java.io.IOException;
import okhttp3.*;

public class OpenAiApi {

    public static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    public static final String OPENAI_API_KEY = "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";
    public static final String OPENAI_API_URL = "https://api.openai.com/v1/completions";

    static OkHttpClient client = new OkHttpClient();

    public static String callOpenAiAPI(String prompt) throws Exception {
        String json = "{\"prompt\": \"" + prompt + "\", \"max_tokens\": 1000, \"model\": \"" + "gpt-3.5-turbo" + "\"}";
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        RequestBody body = RequestBody.create(json, JSON);
        Request request = new Request.Builder()
                .url(OPENAI_API_URL)
                .addHeader("Authorization", "Bearer " + OPENAI_API_KEY)
                .post(body)
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);

            return response.body().string();
        }
    }
}

