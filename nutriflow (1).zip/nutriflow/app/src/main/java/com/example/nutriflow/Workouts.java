package com.example.nutriflow;

public class Workouts
{
    public String calories;

    public Workouts()
    {

    }

    public Workouts(String calories)
    {
        this.calories = calories;
    }

    public String getCalories()
    {
        return calories;
    }

    public void setCalories(String calories)
    {
        this.calories = calories;
    }
}
