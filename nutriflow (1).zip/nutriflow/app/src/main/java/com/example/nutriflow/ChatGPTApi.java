package com.example.nutriflow;

import java.io.IOException;

import okhttp3.*;

public class ChatGPTApi {

    public interface ChatGPTCallback {
        void onSuccess(String result);

        void onFailure(IOException e);
    }

    public static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    public static final String OPENAI_API_KEY = "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";

    static OkHttpClient client;

    static {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        builder.readTimeout(120, java.util.concurrent.TimeUnit.SECONDS); // Setting read timeout to 60 seconds
        builder.writeTimeout(120, java.util.concurrent.TimeUnit.SECONDS); // Setting write timeout to 60 seconds
        client = builder.build();
    }

    public static void run(String userMessage, final ChatGPTCallback callback) throws Exception {
        String url = "https://api.openai.com/v1/chat/completions";
        String json = "{\n" +
                " \"model\": \"gpt-3.5-turbo\",\n" +
                " \"messages\": [{\"role\": \"user\", \"content\": \"" + userMessage + "\"}]\n" +
                " }";

        RequestBody body = RequestBody.create(json, JSON);
        Request request = new Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer " + OPENAI_API_KEY)
                .addHeader("Content-Type", "application/json")
                .post(body)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                callback.onFailure(e);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    callback.onFailure(new IOException("Unexpected code " + response));
                    return;
                }

                String result = response.body().string();
                callback.onSuccess(result);
            }
        });
    }
}
